﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using PRG_282_Project.Business;

namespace PRG_282_Project.Data
{
    internal class DataHandler
    {
        // Create new logic object
        private MedicalLogicDatabase logic = new MedicalLogicDatabase();
        public static string DataPath = Path.Combine(
            Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..")),
            "Data",
            "MedicalStudentDatabase.txt"
        );

        public void GetMedicalStudentDatabase()
        {
            string[] allData = File.ReadAllLines(DataPath);
            logic.FormatData(allData);
        }

        // Update Text File
        public void UpdateMedicalDatabase()
        {
            var totalText = new StringBuilder();

            // Adds Students to total Text
            foreach (var student in Program.Students)
            {
                string id = student.StudentID.ToString();
                string name = student.Name;
                string surname = student.Surname; // Fixed typo from 'surmame' to 'surname'
                string age = student.Age.ToString();
                string course = student.Course;
                string yearOfStudy = student.YearOfStudy.ToString();

                totalText.AppendFormat("{0},{1},{2},{3},{4},{5}\n", id, name, surname, age, course, yearOfStudy);
            }

            File.WriteAllText(DataPath, totalText.ToString());
        }
    }
}
