using PRG_282_Project.Data;

namespace PRG_282_Project
{
	//Student Object
	public class Student
	{
		public int StudentID { get; set; }
		public string Name { get; set; }
		public string Surname { get; set; }
		public int Age { get; set; }
		public string Course { get; set; }
		public int YearOfStudy { get; set; }

		//Constructor
		public Student(int studentID, string name, string surname, int age, string course, int yearOfStudy)
		{
			this.StudentID = studentID;
			this.Name = name;
			this.Surname = surname;
			this.Age = age;
			this.Course = course;
			this.YearOfStudy = yearOfStudy;
		}
	}
	internal static class Program
	{
		//Create a Public List for the Students
		public static List<Student> Students = new List<Student>();
		public static List<Student> SearchedStudents = new List<Student>();

		//Public Vars For Summary
		public static int TotalFirstYears;
		public static int TotalSecondYears;
		public static int TotalThirdYears;
		public static int TotalForthYears;

		public static int AverageFirstYearAge;
		public static int AverageSecondYearAge;
		public static int AverageThirdYearAge;
		public static int AverageForthYearAge;

		/// <summary>
		///  The main entry point for the application.
		/// </summary>
		[STAThread]
        static void Main()
		{
			//Run Data Handler
			DataHandler dataHandler = new DataHandler();
			dataHandler.GetMedicalStudentDatabase();

			// To customize application configuration such as set high DPI settings or default font,
			// see https://aka.ms/applicationconfiguration.
			ApplicationConfiguration.Initialize();
			Application.Run(new Form1());
		}
	}
}