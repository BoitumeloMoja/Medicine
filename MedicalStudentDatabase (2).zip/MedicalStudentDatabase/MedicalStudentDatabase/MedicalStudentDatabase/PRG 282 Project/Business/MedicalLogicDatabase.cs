﻿using PRG_282_Project.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG_282_Project.Business
{
	internal class MedicalLogicDatabase

    {
        //Creating Students From Data Base
        public void FormatData(string[] AllData)
        {
            foreach (var item in AllData)
            {
                string[] StudentInfo = item.Split(new char[] { ',' });

                int studentID = Convert.ToInt32(StudentInfo[0]);
                string name = StudentInfo[1];
                string surname = StudentInfo[2];
                int age = Convert.ToInt32(StudentInfo[3]);
                string course = StudentInfo[4];
                int yearOfStudy = Convert.ToInt32(StudentInfo[5]);

                Student newStudent = new Student(studentID, name, surname, age, course, yearOfStudy);
                Program.Students.Add(newStudent);
            }
        }

        //Insert Student
        public void InsertStudent(string id, string name, string surname, string age, string course, string yearOfStudy)
        {
            Student newStudent = new Student(Convert.ToInt32(id),
            name, surname, Convert.ToInt32(age), course, Convert.ToInt32(yearOfStudy));
            Program.Students.Add(newStudent);

            MessageBox.Show($"{newStudent.Name} has been Added");

            //New Data Handler
            DataHandler dataHandler = new DataHandler();
            dataHandler.UpdateMedicalDatabase();
        }

        //Search For Student
        public void SearchStudents(string SearchedText)
        {
            SearchedText = SearchedText.ToLower();
            Program.SearchedStudents = new List<Student>();


            foreach (Student student in Program.Students)
            {
                if (student.StudentID.ToString().Contains(SearchedText) ||
                    student.Name.ToLower().Contains(SearchedText) ||
                    student.Surname.ToLower().Contains(SearchedText) ||
                    student.Age.ToString().Contains(SearchedText) ||
                    student.Course.ToLower().Contains(SearchedText) ||
                    student.YearOfStudy.ToString().Contains(SearchedText))
                {
                    Program.SearchedStudents.Add(student);
                }
            }
            if (Program.SearchedStudents.Count == 0)
            {
                MessageBox.Show("No Student Found From Searched Text");
            }
        }
        //Update Student
        public void UpdateMedicalDatabase(string selectedStudentID, string id, string name, string surname, string age, string course, string yos)
        {
            foreach (Student student in Program.Students)
            {
                if (student.StudentID == Convert.ToInt32(selectedStudentID))
                {
                    student.StudentID = Convert.ToInt32(id);
                    student.Name = name;
                    student.Surname = surname;
                    student.Age = Convert.ToInt32(age);
                    student.Course = course;
                    student.YearOfStudy = Convert.ToInt32(yos);
                }
            }

            MessageBox.Show($"{name} has been Updated");

            //New Data Handler
            DataHandler dataHandler = new DataHandler();
            dataHandler.UpdateMedicalDatabase();
        }

        //Delete Student
        public void DeleteStudent(string selectedStudentID)
        {
            List<Student> studentsToRemove = new List<Student>();

            // Collect students to remove in a separate list
            foreach (Student student in Program.Students)
            {
                if (student.StudentID == Convert.ToInt32(selectedStudentID))
                {
                    studentsToRemove.Add(student);
                }
            }

            // Remove the students after the loop
            foreach (var student in studentsToRemove)
            {
                Program.Students.Remove(student);
                MessageBox.Show($"{student.Name} has been Deleted");
            }
            //New Data Handler
            DataHandler dataHandler = new DataHandler();
            dataHandler.UpdateMedicalDatabase();
        }
        //Calculation for Average Age
        public void CalculateSummary()
        {
            // Initialize age totals and counts for each year
            int totalAgeByYear1 = 0, totalCountByYear1 = 0;
            int totalAgeByYear2 = 0, totalCountByYear2 = 0;
            int totalAgeByYear3 = 0, totalCountByYear3 = 0;
            int totalAgeByYear4 = 0, totalCountByYear4 = 0;

            // Loop through each student
            foreach (var student in Program.Students)
            {
                switch (student.YearOfStudy)
                {
                    case 1:
                        totalAgeByYear1 += student.Age;
                        totalCountByYear1++;
                        break;
                    case 2:
                        totalAgeByYear2 += student.Age;
                        totalCountByYear2++;
                        break;
                    case 3:
                        totalAgeByYear3 += student.Age;
                        totalCountByYear3++;
                        break;
                    case 4:
                        totalAgeByYear4 += student.Age;
                        totalCountByYear4++;
                        break;
                }
            }

            // Save the total counts to the Program
            Program.TotalFirstYears = totalCountByYear1;
            Program.TotalSecondYears = totalCountByYear2;
            Program.TotalThirdYears = totalCountByYear3;
            Program.TotalForthYears = totalCountByYear4;

            // Calculate and save average ages, ensuring no division by zero
            Program.AverageFirstYearAge = totalCountByYear1 > 0 ? totalAgeByYear1 / totalCountByYear1 : 0;
            Program.AverageSecondYearAge = totalCountByYear2 > 0 ? totalAgeByYear2 / totalCountByYear2 : 0;
            Program.AverageThirdYearAge = totalCountByYear3 > 0 ? totalAgeByYear3 / totalCountByYear3 : 0;
            Program.AverageForthYearAge = totalCountByYear4 > 0 ? totalAgeByYear4 / totalCountByYear4 : 0;
        }
    }
}

