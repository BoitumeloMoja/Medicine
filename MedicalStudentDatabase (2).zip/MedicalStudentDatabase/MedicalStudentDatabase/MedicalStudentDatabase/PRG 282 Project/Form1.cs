using PRG_282_Project.Business;
using System.Runtime.CompilerServices;

namespace PRG_282_Project
{
	public partial class Form1 : Form
	{

		public Form1()
		{	
			InitializeComponent();
			this.Load += LoadHomePageForm;
		}

		private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{

		}

		private void insertStudentToolStripMenuItem_Click(object sender, EventArgs e)
		{
			InsertStudentForm();
		}

		private void label1_Click_1(object sender, EventArgs e)
		{

		}
		//Home Page
		private void LoadHomePageForm(object sender, EventArgs e)
		{
			ShowHomePageForm();
		}
		private void ShowHomePageForm()
		{
			//Clear Panel
			panel1.Controls.Clear();
			//Heading Lable
			Label Heading = new Label
			{
				Text = "M-U-SD",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 5 / 100),
				Width = panel1.Width * 45 / 100,
				Height = panel1.Height * 20 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 30, FontStyle.Bold)
			};

			//Group Members
			Label GroupMembers = new Label
			{
				Text = "Group Members:\n" +
				"- 601193: Qiniso Mngomezulu\n" +
				"- 600508: Neo Polori \n" +
				"- 600508: Boitimelo Moja \n" +
				"- 601377: Teleki Shai",

				Location = new Point(panel1.Width * 65 / 100, panel1.Height * 5 / 100),
				Width = panel1.Width * 31 / 100,
				Height = panel1.Height * 20 / 100,
				Font = new Font(Font.FontFamily, 10, FontStyle.Bold)
			};

            //Body
            Label Body = new Label
            {
                Text = "Medical University Student Management System\r\n" +
           "Task: Develop a C# Windows Forms application that manages medical student records using text files and incorporates Git version control. The application includes the following features:\r\n" +
           "1. Add New Student: Through a form interface, allow the user to input student details (Student ID, Name, Age, and Course) and save these details to a file called students.txt.\r\n" +
           "2. View All Students: Display all student records from students.txt in a DataGridView.\r\n" +
           "3. Update Student Information: Enable the user to search for a student by ID, update their details through a form, and save changes.\r\n" +
           "4. Delete a Student: Allow the user to select a student from the DataGridView and delete the corresponding record from the file.\r\n" +
           "5. Generate a Summary Report: Calculate the total number of students and the average age, and display the results on the form, saving this summary to a file named summary.txt.\r\n" +
           "6. Version Control with Git:\r\n" +
           "� Initialize a Git repository for the project.\r\n" +
           "� Stage and commit changes after each major modification (add, update, delete, or report generation).\r\n" +
           "� Push the repository to GitHub.",

                Location = new Point(panel1.Width * 5 / 100, panel1.Height * 25 / 100),
                Width = panel1.Width * 90 / 100,
                Height = panel1.Height * 70 / 100,
                Font = new Font(Font.FontFamily, 12, FontStyle.Regular),
                ForeColor = Color.Black, // Set text color to White for better visibility on Grey background
                BackColor = Color.Transparent // Make the background transparent if needed
            };

            // Add the label to the panel
            panel1.Controls.Add(Body);

            //Adds To Panel
            panel1.Controls.Add(Heading);
            panel1.Controls.Add(GroupMembers);
			panel1.Controls.Add(Body);

		}
		//Insert Student Form

		private TextBox textID, textName, textSurname, textAge, textYos;
		private ComboBox Course;
		private void InsertStudentForm()
		{
			MedicalLogicDatabase logic = new MedicalLogicDatabase();
			panel1.Controls.Clear();

			Label lblStudentID = new Label
			{
				Text = "Student ID:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 7 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};

			textID = new TextBox
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 7 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblName = new Label
			{
				Text = "Student's Name:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 21 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			textName = new TextBox
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 21 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblSurname = new Label
			{
				Text = "Student's Surname:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 35 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			textSurname = new TextBox
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 35 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblAge = new Label
			{
				Text = "Student's Age:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 49 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			textAge = new TextBox
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 49 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblCourse = new Label
			{
				Text = "Course:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 63 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			Course = new ComboBox
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 63 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				DropDownStyle = ComboBoxStyle.DropDownList // This prevents users from typing a custom entry
			};

			// Add course options
			Course.Items.AddRange(new string[] { "Pharmacy", "MBChb", "Dental Hygeine", "Occupational Therapy", "Nursing" });

			Label lblYoS = new Label
			{
				Text = "Years of Study:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 77 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			textYos = new TextBox
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 77 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100
			};

			// Add a button to save the input
			Button btnSave = new Button
			{
				Text = "Save",
				Location = new Point(panel1.Width * 35 / 100, panel1.Height * 90 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 7 / 100,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold),
				BackColor = Color.DarkCyan
			};
			btnSave.FlatStyle = FlatStyle.Flat;
			btnSave.FlatAppearance.BorderColor = Color.Black;
			btnSave.Click += (s, e) => SaveBtnClicked();


			// Add controls to the panel
			panel1.Controls.Add(lblStudentID);
			panel1.Controls.Add(textID);
			panel1.Controls.Add(lblName);
			panel1.Controls.Add(textName);
			panel1.Controls.Add(lblSurname);
			panel1.Controls.Add(textSurname);
			panel1.Controls.Add(lblAge);
			panel1.Controls.Add(textAge);
			panel1.Controls.Add(lblCourse);
			panel1.Controls.Add(Course);
			panel1.Controls.Add(lblYoS);
			panel1.Controls.Add(textYos);
			panel1.Controls.Add(btnSave);
		}

		private void SaveBtnClicked()
		{
			//New Logic Onject
			MedicalLogicDatabase logic = new MedicalLogicDatabase();

			// Ensure all fields have values before attempting to update
			if (string.IsNullOrWhiteSpace(textID.Text) || string.IsNullOrWhiteSpace(textName.Text) ||
			string.IsNullOrWhiteSpace(textSurname.Text) || string.IsNullOrWhiteSpace(textAge.Text) ||
			string.IsNullOrWhiteSpace(Course.Text) || string.IsNullOrWhiteSpace(textYos.Text))
			{
				MessageBox.Show("Please fill in all fields.",
								"Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
			else if (!int.TryParse(textID.Text, out _) || !int.TryParse(textAge.Text, out _) || !int.TryParse(textYos.Text, out _))
			{
				MessageBox.Show("ID, Age, Year of Study Must be Int!",
								"Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}
			else
			{
				logic.InsertStudent(textID.Text, textName.Text, textSurname.Text, textAge.Text, Course.Text, textYos.Text);


				InsertStudentForm();
			}
		}

		//View All Students Form
		private void ViewAllStudentsForm()
		{
			//Create new Logic Item
			MedicalLogicDatabase logic = new MedicalLogicDatabase();
			// Clears Panel
			panel1.Controls.Clear();

			// Create List Object for Student Data
			ListView listView = new ListView
			{
				Location = new Point((int)(panel1.Width * 5 / 100), (int)(panel1.Height * 15 / 100)),
				Width = (int)(panel1.Width * 90 / 100),
				Height = (int)(panel1.Height * 80 / 100),
				GridLines = true,
				FullRowSelect = true,
				View = View.Details,
				OwnerDraw = true
			};

			//Add Search Bar
			TextBox SearchBar = new TextBox
			{
				Location = new Point(panel1.Width * 50 / 100, panel1.Height * 5 / 100),
				Width = panel1.Width * 25 / 100,
				Height = (int)(panel1.Height * 5 / 100)
			};
			Button RefreshBtn = new Button
			{
				Text = "Refresh",
				Location = new Point(panel1.Width * 85 / 100, panel1.Height * 5 / 100),
				Width = (int)(panel1.Width * 1 / 10),
				Height = (int)(panel1.Height * 5 / 100),
				Font = new Font(Font.FontFamily, 8, FontStyle.Bold),
				BackColor = Color.DarkCyan
			};
			RefreshBtn.FlatStyle = FlatStyle.Flat;
			RefreshBtn.FlatAppearance.BorderColor = Color.Black;
			RefreshBtn.Click += (s, e) => Program.SearchedStudents = new List<Student>();
			RefreshBtn.Click += (s, e) => ViewAllStudentsForm();

			Button SearchBtn = new Button
			{
				Text = "Search",
				Location = new Point(panel1.Width * 75 / 100, panel1.Height * 5 / 100),
				Width = (int)(panel1.Width * 1 / 10),
				Height = (int)(panel1.Height * 5 / 100),
				Font = new Font(Font.FontFamily, 8, FontStyle.Bold),
				BackColor = Color.DarkCyan
			};
			SearchBtn.FlatStyle = FlatStyle.Flat;
			SearchBtn.FlatAppearance.BorderColor = Color.Black;
			SearchBtn.Click += (s, e) => logic.SearchStudents(SearchBar.Text);
			SearchBtn.Click += (s, e) => SearchBar.Refresh();
			SearchBtn.Click += (s, e) => ViewAllStudentsForm();


			// Adds Columns
			listView.Columns.Add("Student ID", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Name", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Surname", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Age", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Course", listView.Width / 6, HorizontalAlignment.Left);
			listView.Columns.Add("Year of Study", listView.Width / 6, HorizontalAlignment.Left);

			//If there is searched Students
			if (Program.SearchedStudents.Count > 0)
			{
				// Adds Students to List
				foreach (Student student in Program.SearchedStudents)
				{
					ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
					item.SubItems.Add(student.Name);
					item.SubItems.Add(student.Surname);
					item.SubItems.Add(Convert.ToString(student.Age));
					item.SubItems.Add(student.Course);
					item.SubItems.Add(Convert.ToString(student.YearOfStudy));

					// Adds item to listView
					listView.Items.Add(item);
				}
			}
			else
			{
				// Adds Students to List
				foreach (Student student in Program.Students)
				{
					ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
					item.SubItems.Add(student.Name);
					item.SubItems.Add(student.Surname);
					item.SubItems.Add(Convert.ToString(student.Age));
					item.SubItems.Add(student.Course);
					item.SubItems.Add(Convert.ToString(student.YearOfStudy));

					// Adds item to listView
					listView.Items.Add(item);
				}
			}

			// Custom draw event handlers
			listView.DrawColumnHeader += ListView_DrawColumnHeader;
			listView.DrawItem += ListView_DrawItem;

			// Adds List View to Panel
			panel1.Controls.Add(SearchBar);
			panel1.Controls.Add(SearchBtn);
			panel1.Controls.Add(RefreshBtn);
			panel1.Controls.Add(listView);
		}

		// Event handler for drawing the column headers
		private void ListView_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
		{
			// Set the background color and text format
			using (Brush headerBackgroundBrush = new SolidBrush(Color.LightGray))
			using (Font headerFont = new Font(e.Font, FontStyle.Bold))
			{
				e.Graphics.FillRectangle(headerBackgroundBrush, e.Bounds);
				TextRenderer.DrawText(e.Graphics, e.Header.Text, headerFont, e.Bounds, Color.Black, TextFormatFlags.Left);
			}
			e.DrawDefault = false;
		}

		// This event must be handled even if not custom drawing the items
		private void ListView_DrawItem(object sender, DrawListViewItemEventArgs e)
		{
			e.DrawDefault = true;
		}

		private void allStudentsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ViewAllStudentsForm();
		}

		private ListView lstStudents;
		private TextBox txtID, txtName, txtSurname, txtAge, txtYos;
		private ComboBox comboCourse;

		private void ShowUpdateStudentForm()
		{
			// Clear existing controls on the panel
			panel1.Controls.Clear();

			// Initialize the ListBox for displaying student entries
			lstStudents = new ListView
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 5 / 100),
				Width = panel1.Width * 40 / 100,
				Height = panel1.Height * 90 / 100,
				GridLines = true,
				FullRowSelect = true,
				View = View.Details,
				OwnerDraw = true
			};

			//Make Columbs
			lstStudents.Columns.Add("Student ID", lstStudents.Width / 3, HorizontalAlignment.Left);
			lstStudents.Columns.Add("Name", lstStudents.Width / 3, HorizontalAlignment.Left);
			lstStudents.Columns.Add("Surname", lstStudents.Width / 3, HorizontalAlignment.Left);

			//adds Students to list
			foreach (Student student in Program.Students)
			{
				ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
				item.SubItems.Add(student.Name);
				item.SubItems.Add(student.Surname);

				//Addd item
				lstStudents.Items.Add(item);
			}

			// Custom draw event handlers
			lstStudents.DrawColumnHeader += ListView_DrawColumnHeader;
			lstStudents.DrawItem += ListView_DrawItem;

			// Create labels and textboxes for student details
			Label lblID = new Label
			{
				Text = "Student ID:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 7 / 100),
				Width = panel1.Width * 15 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			txtID = new TextBox
			{
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 7 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblName = new Label
			{
				Text = " Student:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 21 / 100),
				Width = panel1.Width * 15 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			txtName = new TextBox
			{
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 21 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblSurname = new Label
			{
				Text = "Surname:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 35 / 100),
				Width = panel1.Width * 15 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			txtSurname = new TextBox
			{
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 35 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblAge = new Label
			{
				Text = "Age:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 49 / 100),
				Width = panel1.Width * 15 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			txtAge = new TextBox
			{
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 49 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100
			};

			Label lblCourse = new Label
			{
				Text = "Course:",
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 63 / 100),
				Width = panel1.Width * 15 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			comboCourse = new ComboBox
			{
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 63 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100,
				DropDownStyle = ComboBoxStyle.DropDownList // This prevents users from typing a custom entry
			};

			// Add course options
			comboCourse.Items.AddRange(new string[] { "Pharmacy", "MBChb", "Dental Hygeine", "Occupational Therapy", "Nursing" });

			Label lblYoS = new Label
			{
				Text = "Years of Study:",
				Location = new Point(panel1.Width * 3 / 100, panel1.Height * 77 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100,
				TextAlign = ContentAlignment.TopCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold)
			};
			txtYos = new TextBox
			{
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 77 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100
			};


			// Add a button to update the student details
			Button btnUpdate = new Button
			{
				Text = "Update",
				Location = new Point(panel1.Width * 15 / 100, panel1.Height * 90 / 100),
				Width = panel1.Width * 20 / 100,
				Height = panel1.Height * 7 / 100,
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold),
				BackColor = Color.DarkCyan
			};
			btnUpdate.FlatStyle = FlatStyle.Flat;
			btnUpdate.FlatAppearance.BorderColor = Color.Black;
			btnUpdate.Click += (s, e) => UpdateBtnClick();

			// Add controls to the panel
			panel1.Controls.Add(lblID);
			panel1.Controls.Add(txtID);
			panel1.Controls.Add(lblName);
			panel1.Controls.Add(txtName);
			panel1.Controls.Add(lblSurname);
			panel1.Controls.Add(txtSurname);
			panel1.Controls.Add(lblAge);
			panel1.Controls.Add(txtAge);
			panel1.Controls.Add(lblCourse);
			panel1.Controls.Add(comboCourse);
			panel1.Controls.Add(lblYoS);
			panel1.Controls.Add(txtYos);
			panel1.Controls.Add(btnUpdate);
			panel1.Controls.Add(lstStudents);
		}

		private void UpdateBtnClick()
		{
			//New Logic Onject
			MedicalLogicDatabase logic = new MedicalLogicDatabase();

			if (lstStudents.SelectedItems.Count > 0)
			{
				// Ensure all fields have values before attempting to update
				if (string.IsNullOrWhiteSpace(txtID.Text) || string.IsNullOrWhiteSpace(txtName.Text) ||
				string.IsNullOrWhiteSpace(txtSurname.Text) || string.IsNullOrWhiteSpace(txtAge.Text) ||
				string.IsNullOrWhiteSpace(comboCourse.Text) || string.IsNullOrWhiteSpace(txtYos.Text))
				{
					MessageBox.Show("Please fill in all fields.",
									"Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
				else if (!int.TryParse(txtID.Text, out _) || !int.TryParse(txtAge.Text, out _) || !int.TryParse(txtYos.Text, out _))
				{
					MessageBox.Show("ID, Age, Year of Study Must be Int!",
									"Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
				else
				{
					// Get Selected Student
					ListViewItem selectedStudent = lstStudents.SelectedItems[0];

					// Run Update Student
					logic.UpdateMedicalDatabase(selectedStudent.Text, txtID.Text, txtName.Text, txtSurname.Text, txtAge.Text, comboCourse.Text, txtYos.Text);

					MessageBox.Show("Student Updated Successfully");

					//Clear TextBoxes
					txtID.Text = "";
					txtName.Text = "";
					txtSurname.Text = "";
					txtAge.Text = "";
					comboCourse.Text = "";
					txtYos.Text = "";

					// Show Update Student Form Again
					ShowUpdateStudentForm();
				}
			}
			else
			{
				MessageBox.Show("Please Select a Student from the List Box");
			}
		}

		//Summary Form
		private void ViewSummaryForm()
		{
			//Clears Panel1
			panel1.Controls.Clear();

			//Add Student Sammary label
			Label StudentSummaryHeading = new Label
			{
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 5 / 100),
				Width = (int)(panel1.Width * 90 / 100),
				Height = (int)(panel1.Height * 30 / 100),
				Text = "Student Summary",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 40, FontStyle.Bold)
			};

			//First Year Label
			Label FirstYearLable = new Label
			{
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 35 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Total First Year Students : {Program.TotalFirstYears}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};
			Label AverageAgeFirstYearLable = new Label
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 35 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Average First Year Age : {Program.AverageFirstYearAge}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};

			//First Year Label
			Label SecondYearLable = new Label
			{
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 50 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Total Second Year Students : {Program.TotalSecondYears}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};
			Label AverageAgeSecondYearLable = new Label
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 50 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Average Second Year Age : {Program.AverageSecondYearAge}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};

			//First Year Label
			Label ThirdYearLable = new Label
			{
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 65 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Total Third Year Students : {Program.TotalThirdYears}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};
			Label AverageAgeThirdYearLable = new Label
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 65 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Average Third Year Age : {Program.AverageThirdYearAge}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};

			//First Year Label
			Label ForthYearLable = new Label
			{
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 80 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Total Forth Year Students : {Program.TotalForthYears}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};
			Label AverageAgeForthYearLable = new Label
			{
				Location = new Point(panel1.Width * 55 / 100, panel1.Height * 80 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Text = $"Average Forth Year Age : {Program.AverageForthYearAge}",
				TextAlign = ContentAlignment.MiddleCenter,
				Font = new Font(Font.FontFamily, 13, FontStyle.Regular)
			};

			//Add To panel1
			panel1.Controls.Add(StudentSummaryHeading);
			panel1.Controls.Add(FirstYearLable);
			panel1.Controls.Add(AverageAgeFirstYearLable);
			panel1.Controls.Add(SecondYearLable);
			panel1.Controls.Add(AverageAgeSecondYearLable);
			panel1.Controls.Add(ThirdYearLable);
			panel1.Controls.Add(AverageAgeThirdYearLable);
			panel1.Controls.Add(ForthYearLable);
			panel1.Controls.Add(AverageAgeForthYearLable);
		}

		private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
		{
			//New Logic Object
			MedicalLogicDatabase logic = new MedicalLogicDatabase();
			logic.CalculateSummary();

			ViewSummaryForm();
		}

		private void updateStudentToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowUpdateStudentForm();
		}

		private void homeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowHomePageForm();
		}

		private ListView ViewStudents;

		private void ShowDeleteStudentForm()
		{
			// Clear existing controls on the panel
			panel1.Controls.Clear();

			// Initialize the ListView for displaying students
			ViewStudents = new ListView
			{
				Location = new Point(panel1.Width * 5 / 100, panel1.Height * 5 / 100),
				Width = (int)(panel1.Width * 90 / 100),
				Height = (int)(panel1.Height * 75 / 100),
				View = View.Details,
				FullRowSelect = true,
				GridLines = true,
				OwnerDraw = true
			};

			// Add columns to the ListView
			ViewStudents.Columns.Add("Student ID", ViewStudents.Width / 6, HorizontalAlignment.Left);
			ViewStudents.Columns.Add("Name", ViewStudents.Width / 6, HorizontalAlignment.Left);
			ViewStudents.Columns.Add("Surname", ViewStudents.Width / 6, HorizontalAlignment.Left);
			ViewStudents.Columns.Add("Age", ViewStudents.Width / 6, HorizontalAlignment.Left);
			ViewStudents.Columns.Add("Course", ViewStudents.Width / 6, HorizontalAlignment.Left);
			ViewStudents.Columns.Add("Year of Study", ViewStudents.Width / 6, HorizontalAlignment.Left);

			// Load students into the ListView
			foreach (Student student in Program.Students)
			{
				ListViewItem item = new ListViewItem(Convert.ToString(student.StudentID));
				item.SubItems.Add(student.Name);
				item.SubItems.Add(student.Surname);
				item.SubItems.Add(Convert.ToString(student.Age));
				item.SubItems.Add(student.Course);
				item.SubItems.Add(Convert.ToString(student.YearOfStudy));

				//Adds Item
				ViewStudents.Items.Add(item);
			}
			// Custom draw event handlers
			ViewStudents.DrawColumnHeader += ListView_DrawColumnHeader;
			ViewStudents.DrawItem += ListView_DrawItem;


			// Create a button to delete the selected student
			Button DeleteBtn = new Button
			{
				Text = "Delete",
				Location = new Point(panel1.Width * 30 / 100, panel1.Height * 85 / 100),
				Width = (int)(panel1.Width * 40 / 100),
				Height = (int)(panel1.Height * 10 / 100),
				Font = new Font(Font.FontFamily, 13, FontStyle.Bold),
				BackColor = Color.DarkCyan
			};
			DeleteBtn.FlatStyle = FlatStyle.Flat;
			DeleteBtn.FlatAppearance.BorderColor = Color.Black;
			DeleteBtn.Click += (s, e) => DeleteBtnClicked();

			// Add controls to the panel
			panel1.Controls.Add(ViewStudents);
			panel1.Controls.Add(DeleteBtn);
		}

		private void DeleteBtnClicked()
		{
			//New Logic Onject
			MedicalLogicDatabase logic = new MedicalLogicDatabase();

			if (ViewStudents.SelectedItems.Count > 0)
			{
				// Get Selected Student
				ListViewItem selectedStudent = ViewStudents.SelectedItems[0];
				logic.DeleteStudent(selectedStudent.Text);

				ShowDeleteStudentForm();
			}
			else
			{
				MessageBox.Show("Please Select a Student from the List Box");
			}
		}

		private void deleteStudentToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ShowDeleteStudentForm();
		}
	}
}
